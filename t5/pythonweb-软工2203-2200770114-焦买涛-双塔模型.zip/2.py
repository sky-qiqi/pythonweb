import tensorflow as tf
import tensorflow_recommenders as tfrs
import keras
print(f"TensorFlow version: {tf.__version__}")
print(f"TensorFlow Recommenders version: {tfrs.__version__}")
print(f"Keras version: {keras.__version__}")